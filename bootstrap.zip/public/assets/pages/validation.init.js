/*
 Template Name: Zoogler - Bootstrap 4 Admin Dashboard
 Author: Mannatthemes
 Website: www.mannatthemes.com
 File: validationinit js
 */

$(document).ready(function() {
    $('form').parsley();
});