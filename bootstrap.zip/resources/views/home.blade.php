@extends('layouts.app')

@section('content')
<div class="container-fluid">



</div>
@endsection

@section('scripts')

@endsection