

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">
                    <a class="mb-2 mr-2 btn btn-info" style="float:right;" href="<?php echo e(route('application.create')); ?>">New Application
                        </a>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"></h5>
                        <table class="mb-0 table" id="example">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>SR Number</th>
                                    <th>Letter Number</th>
                                    <th>Applicant Name</th>
                                    <th>Request Date</th>
                                    <th>Action</th>
                                </tr>
                                <tr>
                                    <th></th>
                                    <th><input type="text" /></th>
                                    <th><input type="text" /></th>
                                    <th><input type="text" /></th>
                                    <th><input type="text" /></th>
                                    <th></th>
                                </tr>
                            </thead>
                            
                            
                            <tbody>

                                <?php if(isset($applications)): ?>                                    
                                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->id); ?></td>
                                        <td><?php echo e($data->sr_number); ?></td>
                                        <td><?php echo e($data->applicant_civil_id); ?></td>
                                        <td><?php echo e($data->applicant_name); ?></td>
                                        <td><?php echo e($data->action_date); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('application.delete', $data->id)); ?>" method="POST">
                                                <a href="<?php echo e(route('application.edit', $data->id)); ?>"
                                                    class="btn btn-primary">Edit</a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo e(method_field('DELETE')); ?>

                                                <button class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function () {
    
    // DataTable
    var table = $('#example').DataTable({
        initComplete: function () {
            // Apply the search
            this.api()
                .columns()
                .every(function () {
                    var that = this;
 
                    $('input', this.header()).on('keyup change clear', function () {
                        if (that.search() !== this.value) {
                            that.search(this.value).draw();
                        }
                    });
                });
        },
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\fivver-app\resources\views/application/index.blade.php ENDPATH**/ ?>