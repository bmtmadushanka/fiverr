
<?php $__env->startSection('content'); ?>
<?php $permission = app('App\Classes\permission'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header">
            <?php if($permission->permitted('users-add')=='success'): ?>
                    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary" style="float:right;">
                        <i class="fas fa-plus"></i>
                        New User
                    </a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <!--begin: Datatable-->
                <table class="table table-bordered table-hover table-checkable" id="users-table">
                    <thead>
                        <tr>
                            <th style="width:7%">ID</th>
                            <th style="width:22%">User</th>
                            <th style="width:27%">Contact</th>
                            <th style="width:10%">Role</th>
                            <th style="width:10%">Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($users)): ?>                                    
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->id); ?></td>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php echo e($data->role); ?></td>
                                <td><?php if($data->status==1): ?>Active <?php else: ?> Deactive <?php endif; ?></td>
                                <td>
                                    <form action="<?php echo e(route('user.delete', $data->id)); ?>" method="POST">
                                        <a href="<?php echo e(route('user.edit', $data->id)); ?>"
                                            class="btn btn-primary">Edit</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('DELETE')); ?>

                                        <button class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <!--end: Datatable-->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\fivver-app\resources\views/users/index.blade.php ENDPATH**/ ?>