
<?php $permission = app('App\Classes\permission'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-header">
                    <a class="mb-2 mr-2 btn btn-info" style="float:right;" href="<?php echo e(route('application.create')); ?>">New Application
                        </a>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"></h5>
                        <table class="mb-0 table" id="example">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>SR Number</th>
                                    <th>Letter Number</th>
                                    <th>Applicant Name</th>
                                    <th>Request Date</th>
                                    <th>Action</th>
                                </tr>
                                <tr>
                                    <th></th>
                                    <th><input type="text" /></th>
                                    <th><input type="text" /></th>
                                    <th><input type="text" /></th>
                                    <th><input type="text" /></th>
                                    <th></th>
                                </tr>
                            </thead>


                            <tbody>

                                <?php if(isset($applications)): ?>
                                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->id); ?></td>
                                        <td><?php echo e($data->sr_number); ?></td>
                                        <td><?php echo e($data->applicant_civil_id); ?></td>
                                        <td><?php echo e($data->applicant_name); ?></td>
                                        <td><?php echo e($data->action_date); ?></td>
                                        <td>
                                        <?php if($permission->permitted('request-edit')=='success'): ?>

                                                <a href="<?php echo e(route('application.edit', $data->id)); ?>"
                                                    class="btn btn-primary">Edit</a>
                                        <?php endif; ?>
                                        <?php if($permission->permitted('request-history')=='success'): ?>

                                                    <a href="<?php echo e(route('application.history', $data->id)); ?>"
                                                    class="btn btn-primary">History</a>
                                        <?php endif; ?>
                                        <?php if($permission->permitted('request-delete')=='success'): ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger app_delete" data-id="<?php echo e($data->id); ?>">Delete</button>
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function () {

    // DataTable
    var table = $('#example').DataTable({
        initComplete: function () {
            // Apply the search
            this.api()
                .columns()
                .every(function () {
                    var that = this;

                    $('input', this.header()).on('keyup change clear', function () {
                        if (that.search() !== this.value) {
                            that.search(this.value).draw();
                        }
                    });
                });
        },
    });

    $('.app_delete').on('click',function () {
        let t = table;
        let id  = $(this).data('id');
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.value === true) {
                $.ajax({
                    type : 'delete',
                    url : '/application/'+id,
                    success : function (res) {
                        t.ajax.reload();
                        show_success_response(res);
                    },
                    error : function (res) {
                        show_error_response(res);
                    }
                });
            }
        })
    })
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\fivver-app\resources\views/application/index.blade.php ENDPATH**/ ?>