

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary" style="float: right;">Back</a>
            </div>
            <div class="card-body" style=" background-color:#d9eff6;">
                <form action="<?php echo e(route('application.update',$app->id)); ?>" method="POST" class="needs-validation" novalidate enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row form-row" style="background-color:grey">
                        <h5>VIP Order Tracking System</h5>
                    </div>
                    <div class="row form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">Req</label>
                        <div class="col-md-1 mb-3 mt-3">
                            <div class="input-group">
                            <input type="number" name="sr_number" id="sr_number" class="form-control" value="<?php echo e($app->sr_number); ?>" readonly required>
                                <div class="invalid-feedback">
                                    Please Enter SR Number.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">الرقم المدني</label>
                        <div class="col-md-1 mb-3 mt-3">
                            <div class="input-group">
                            <input type="text" name="applicant_civil_id" value="<?php echo e($app->applicant_civil_id); ?>" id="applicant_civil_id" class="form-control numaric" maxlength="12" required>
                                <div class="invalid-feedback">
                                    Please Enter Civil Number.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">الإسم </label>
                        <div class="col-md-7 mb-3 mt-3">
                            <div class="input-group">
                            <input type="text" name="applicant_name" value="<?php echo e($app->applicant_name); ?>" id="applicant_name" class="form-control" required>
                                <div class="invalid-feedback">
                                    Please Enter Applicant Name.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">الإجراء</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="action_taken" id="action_taken" class="form-control select2" required>
                                <option <?php if($app->action_taken == 'بريد وارد'): ?> selected <?php endif; ?>>بريد وارد</option>
                                <option <?php if($app->action_taken == 'تم التنفيذ'): ?> selected <?php endif; ?>>تم التنفيذ</option>
                                <option <?php if($app->action_taken == 'عمل احتياج'): ?> selected <?php endif; ?>>عمل احتياج</option>
                                <option <?php if($app->action_taken == 'ملغي'): ?> selected <?php endif; ?>>ملغي</option>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Action Taken.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">حالة الطلب</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="action_status" id="action_status" class="form-control select2" required>
                                <option <?php if($app->action_status == 'Done'): ?> selected <?php endif; ?>>Done</option>
                                <option <?php if($app->action_status == 'New'): ?> selected <?php endif; ?>>New</option>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Action Status.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">تاريخ الإجراء </label>
                        <div class="col-md-3 mb-3 mt-3">
                            <div class="input-group">
                            <input type="date" name="action_date" value="<?php echo e($app->action_date); ?>" id="action_date" class="form-control" required>
                                <div class="invalid-feedback">
                                    Please Select Action Date.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">الدرجة العلمية</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="applicant_degree" id="applicant_degree" class="form-control select2" required>
                                <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php if($app->applicant_degree == $data->id): ?> selected <?php endif; ?>><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Degree.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">المستوى العلمي</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="applicant_academic" id="applicant_academic" class="form-control select2" required>
                                <option <?php if($app->applicant_academic == 'PHD'): ?> selected <?php endif; ?>>PHD</option>
                                <option <?php if($app->applicant_academic == 'Masters'): ?> selected <?php endif; ?>>Masters</option>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Level.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">المسمى الوظيفي </label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="applicant_job_title" id="applicant_job_title" class="form-control select2" required>
                                <option  <?php if($app->applicant_job_title == 'Job 1'): ?> selected <?php endif; ?>>Job 1</option>
                                <option  <?php if($app->applicant_job_title == 'Job 2'): ?> selected <?php endif; ?>>Job 2</option>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select JOB Title.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">CSC ملاحظات</label>
                        <div class="col-md-7 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="csc_organization"  value="<?php echo e($app->csc_organization); ?>" id="csc_organization" class="form-control" required>
                                <div class="invalid-feedback">
                                    Please Enter CSC Note.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">رقم الصادر</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" value="<?php echo e($app->outgoing_letter_number); ?>" name="outgoing_letter_number" id="outgoing_letter_number" class="form-control numaric" required>
                                <div class="invalid-feedback">
                                    Please Enter Organization Number.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">المصدر</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="source_name" id="source_name" class="form-control select2" required>
                                <option <?php if($app->source_name == 'Source one'): ?> selected <?php endif; ?>>Source one</option>
                                <option <?php if($app->source_name == 'Source Two'): ?> selected <?php endif; ?>>Source Two</option>
                                <option <?php if($app->source_name == 'Source Three'): ?> selected <?php endif; ?>>Source Three</option>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Source.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">صفة المصدر</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="source_description" id="source_description" class="form-control select2" required>
                                <option <?php if($app->source_description == 'Description 1'): ?> selected <?php endif; ?>>Description 1</option>
                                <option <?php if($app->source_description == 'Description 2'): ?> selected <?php endif; ?>>Description 2</option>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Description.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">السكرتير</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="source_secreatary_name" value="<?php echo e($app->source_secreatary_name); ?>" id="source_secreatary_name" class="form-control" required>
                                <div class="invalid-feedback">
                                    Please Enter Secretary Name.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">هاتف السكرتير </label>
                        <div class="col-md-3 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="secreatary_mobile" value="<?php echo e($app->secreatary_mobile); ?>" id="secreatary_mobile" class="form-control numaric" maxlength="9" required>
                                <div class="invalid-feedback">
                                    Please Enter Secreatary Number.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">No.req</label>
                        <div class="col-md-1 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="current_request" value="<?php echo e($app->current_request); ?>" id="current_request" class="form-control numaric" maxlength="3" required>
                                <div class="invalid-feedback">
                                    Please Enter No Of Request.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">Rem.req </label>
                        <div class="col-md-1 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="remaining_request" value="<?php echo e($app->remaining_request); ?>" id="remaining_request" class="form-control numaric" maxlength="3" required>
                                <div class="invalid-feedback">
                                    Please Enter Remaining Request.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">Add.req</label>
                        <div class="col-md-1 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="additional_request" value="<?php echo e($app->additional_request); ?>" id="additional_request" class="form-control numaric" maxlength="3" required>
                                <div class="invalid-feedback">
                                    Please Enter Additional Request.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">Tot.req  </label>
                        <div class="col-md-1 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="total_request" value="<?php echo e($app->total_request); ?>" id="total_request" class="form-control numaric" maxlength="3" required>
                                <div class="invalid-feedback">
                                    Please Enter Total Request.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">Eligible.req  </label>
                        <div class="col-md-1 mb-3 mt-3">
                            <div class="input-group">
                                <input type="text" name="eligible_requests" value="<?php echo e($app->eligible_requests); ?>" id="eligible_requests" class="form-control numaric" maxlength="3" required>
                                <div class="invalid-feedback">
                                    Please Enter Eligible Request.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">الموضوع</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="subject" id="subject" class="form-control select2" required>
                                <option <?php if($app->subject == 'Subject One'): ?> selected <?php endif; ?>>Subject One</option>
                                <option <?php if($app->subject == 'Subject Two'): ?> selected <?php endif; ?>>Subject Two</option>
                                <option <?php if($app->subject == 'Subject Three'): ?> selected <?php endif; ?>>Subject Three</option>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Subject.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">من قطاع</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="from_sector" id="from_sector" class="form-control select2" required>
                                <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php if($app->from_sector == $data->id): ?> selected <?php endif; ?>><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select From Sector.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">إدارة</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="from_department" id="from_department" class="form-control select2" required>
                                <?php $__currentLoopData = $from_departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $from_department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($from_department->id); ?>" <?php if($app->from_department == $from_department->id): ?> selected <?php endif; ?>><?php echo e($from_department->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Department.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">Attachment </label>
                        <div class="col-md-3 mb-3 mt-3">
                            <div class="input-group">
                                <input type="file" name="attachment[]" id="attachment" class="form-control" multiple >
                                <div class="invalid-feedback">
                                    Please select Attachment.
                                </div>
                                <div class="valid-feedback">
                                    Looks good!
                                </div>

                            </div>
                            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-secondary mr-1 mt-1 btn-sm" href="<?php echo e(asset('attachment/'.$file)); ?>" >Document <?php echo e($key+1); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">إلى قطاع</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="to_sector" id="to_sector" class="form-control select2" required>
                                <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>" <?php if($app->to_sector == $data->id): ?> selected <?php endif; ?>><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Sector.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">إدارة</label>
                        <div class="col-md-3 mb-3 mt-3">
                            <select name="to_department" id="to_department" class="form-control select2" required>
                                <?php $__currentLoopData = $to_departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to_department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($to_department->id); ?>" <?php if($app->to_department == $to_department->id): ?> selected <?php endif; ?>><?php echo e($to_department->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">
                                    Please Select Department.
                            </div>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">ملاحظات</label>
                        <div class="col-md-11 mb-3 mt-3">
                            <textarea name="general_notes" cols="147"><?php echo e($app->general_notes); ?> </textarea>
                        </div>
                    </div>
                    <div class="form-row">
                        <label for="" class="col-sm-1 col-form-label mb-3 mt-3">ملاحظات</label>
                        <div class="col-md-11 mb-3 mt-3">
                            <textarea name="special_notes" cols="147"><?php echo e($app->special_notes); ?> </textarea>
                        </div>
                    </div>
                    <div class="form-row">
                        <button class="btn btn-success mb-3 mt-3 mr-2" type="submit">Update Details</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/application_control.js')); ?>"></script>
<script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

    $(document).ready(function () {
        initFromDepartmentSelect();
        initToDepartmentSelect();

        $('#from_department').val(<?php echo e($app->from_department); ?>);
        $('#from_department').trigger('change');
        $('#to_department').val(<?php echo e($app->to_department); ?>);
        $('#to_department').trigger('change');

    });
    /*$('#from_sector').on("change", function(e) {
        //var from_sector = $('#from_sector').val();
        let from_sector = $(this).val();
        $.ajax({
         url: "<?php echo e(route('sector.from_department')); ?>",
         type   : 'POST',
         data     : {
            from_sector : from_sector,
                  },
         success  : function(response){
            $.each(response,function(key, value)
            {
                $("#from_department").append('<option value=' + key + '>' + value + '</option>');
            });

         }
      });


    });
*/
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\fivver-app\resources\views/application/edit.blade.php ENDPATH**/ ?>