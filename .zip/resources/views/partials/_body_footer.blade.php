<div class="app-wrapper-footer">
  <div class="app-footer">
      <div class="app-footer__inner">
          <div class="app-footer-left">
              
          </div>
          <div class="app-footer-right">
              <ul class="nav">
                  <li class="nav-item">
                    
                  </li>
                  <li class="nav-item">
                      <a href="javascript:void(0);" class="nav-link">
                          Okzen Software
                      </a>
                  </li>
              </ul>
          </div>
      </div>
  </div>
</div>